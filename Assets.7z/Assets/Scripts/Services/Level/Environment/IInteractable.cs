﻿public interface IInteractable
{
    void Interact(IPlayer player);
}
